import { PersonaDTO } from "../../Domain/DTOs/PersonaDTO.js";

export interface PersonaConIcono extends PersonaDTO {
  iniciales: string;
}